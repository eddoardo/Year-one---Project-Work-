package controllers;

import models.Biometrics;
import models.Step;
import play.db.DB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import models.Step;
import play.libs.Json;

/**
 * Created by edoardo on 02/08/15. //scrive e legge i dati dal db.
 */
public class DataManagement {

    // TODO trasforma questo in una chiamata a tuaclasse.getSteps
    // TODO completare
    List<Step> steps = null;
    // query sql che ti ritorna un list<Step> steps

    // come si testa? su browser vai su: http://localhost:9000/persons
    // dovresti vedere dati json.

    // trasforma la lista di steps in json e la ritorna, ovvero:



    public List<Biometrics> getBiometrics(){             //get data from db
        Connection conn = DB.getConnection();
        List<Biometrics> bs = new ArrayList();
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM steps");
            while(rs.next()){
                int numOfSteps = rs.getInt("steps_numbers");
                //Time time = rs.getTime("time");

                Biometrics b = new Biometrics();
                b.setStep(numOfSteps);

                bs.add(b);
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return bs ;
        }
    }

    public void putdata(Biometrics biometrics){
        Connection conn = DB.getConnection();
        try {
            Statement st = conn.createStatement();
            String query = "INSERT INTO Steps (steps_numbers, time) values (?, ?)";

            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, biometrics.getStep());
            ps.setTimestamp(2, new java.sql.Timestamp(new java.util.Date().getTime()));

            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }



}
