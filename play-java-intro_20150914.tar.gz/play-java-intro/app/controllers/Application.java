package controllers;

import models.Biometrics;
import models.Person;

import models.Step;
import play.data.Form;
import play.db.DB;
import play.db.jpa.JPA;
import play.db.jpa.Transactional;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;
import views.html.index;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.List;

import static play.libs.Json.toJson;



public class Application extends Controller {

    public Result index() {
        return ok(index.render());
    }


    public Result biometrics() {
        DataManagement dm = new DataManagement();
        List<Biometrics> biometrics = dm.getBiometrics();
        return ok(Json.toJson(biometrics));
    }

    public Result addBiometricsData() {
        Biometrics biometrics = Json.fromJson(request().body().asJson(), Biometrics.class);//change json to biometrics, files from android app

        DataManagement dm = new DataManagement();
        dm.putdata(biometrics);

        System.out.println("Biometrics:" + biometrics.getStep());
        //
        return ok();
    }
}
