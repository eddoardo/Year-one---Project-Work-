package models;

/**
 * Created by edoardo on 21/07/15.
 */
public class Biometrics {

    private int Step;

    public int getStep() {
        return Step;
    }

    public void setStep(int step) {
        Step = step;
    }
}