package models;

import play.api.libs.json.JsPath;
import play.db.DB;
import play.libs.Json;

import java.sql.*;

/**
 * Created by edoardo on 29/07/15.
 */
public class Step {
    // TODO inserire i steps e il time (come su DB)

    public int time = 0;
    public int numberSteps = 0;

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getNumberSteps() {
        return numberSteps;
    }

    public void setNumberSteps(int numberSteps) {
        this.numberSteps = numberSteps;
    }


}
